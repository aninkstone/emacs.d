/* 
 * This source file contains macros to be used by :spp-files slot in the
 * ede/cpp-root project type.
 */

#define FEATURE1 1
#define FEATURE2 2

/* #define FEATURE3 3 */
